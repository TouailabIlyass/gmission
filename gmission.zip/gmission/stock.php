<?php

define("__DB",     "g_mission_emp");
define("__TABLE",     "stock");

if($_SERVER['REQUEST_METHOD'] === 'GET')
{
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once 'Dao.php';
//include_once 'models/Employe.php';
	
	$dao = new Dao(__DB);
	if(isset($_GET['type']))
	{
		$data=$dao->getList(__TABLE,true,"where type = '".$_GET['type']."'");
	    http_response_code(200);
	    echo json_encode($data[0]);
	}
	else
	{
		$data=$dao->getList(__TABLE,true);
	    http_response_code(200);
	    echo json_encode($data);
	}
 	
    $dao->close();
/////
}else if($_SERVER['REQUEST_METHOD'] === 'PUT')
{
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include_once 'Dao.php';
include_once 'models/Stock.php';
$dao = new Dao(__DB);
$data = json_decode(file_get_contents("php://input"));
echo json_encode($data);
$stock = new Stock($data->type,$data->somme);
$dao->update(__TABLE,(array)$data,$stock->getPrimaryKey());
$dao->close();
}
else if($_SERVER['REQUEST_METHOD'] === 'POST')
{
echo "put".$_GET['id'];
}
else if($_SERVER['REQUEST_METHOD'] === 'DELETE')
{

	echo "delete".$_GET['id'];
}