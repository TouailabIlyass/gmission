<?php

define("__DB",     "g_mission_emp");
define("__TABLE",     "employe");

if($_SERVER['REQUEST_METHOD'] === 'GET')
{
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once 'Dao.php';
//include_once 'models/Employe.php';
	
	$dao = new Dao(__DB);
	if(isset($_GET['cin']) && isset($_GET['nom']))
	{
		$employes=$dao->getList(__TABLE,true,"where cin = '".$_GET['cin']."' and nom = '".$_GET['nom']."'");
	    http_response_code(200);
	    echo json_encode($employes);
	}
	else if(isset($_GET['cin']))
	{
		$employes=$dao->getList(__TABLE,true,"where cin = '".$_GET['cin']."'");
	    http_response_code(200);
	    echo json_encode($employes);
	}
	else if(isset($_GET['search']))
	{
		$val = $_GET['search'];
		$employes=$dao->getListJoin("SELECT * FROM employe e LEFT OUTER JOIN mission m ON e.cin = m.cin_emp where (e.nom like '%$val%' or m.date like '%$val%') GROUP by e.cin ",true);
	    http_response_code(200);
	    echo json_encode($employes);
	}
	else
	{
		$employes=$dao->getList(__TABLE,true);
	    http_response_code(200);
		echo json_encode($employes);
	}
 	
    $dao->close();
/////
}else if($_SERVER['REQUEST_METHOD'] === 'POST')
{/////////////

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 

include_once 'Dao.php';
 

$dao = new Dao(__DB);

$data = json_decode(file_get_contents("php://input"));
 if(isset($_GET['action']))
 {
	 if($_GET['action']=='login')
	 {
		$employes=$dao->getList(__TABLE,true,"where cin = '".$data->cin."' and nom = '".$data->nom."'");
	    http_response_code(200);
	    echo json_encode($employes[0]);
	 }
 }else{
	$dao->insert(__TABLE,(array)$data);
	echo json_encode(array("message" => "Employe was created."));
	//$data1=json_decode($data);
	//var_dump((array)$data);
		//echo json_encode(array("message" => "Product was created."));
	/////////
	}
	$dao->close();
}
else if($_SERVER['REQUEST_METHOD'] === 'PUT')
{
echo "put".$_GET['id'];
}
else if($_SERVER['REQUEST_METHOD'] === 'DELETE')
{

	echo "delete".$_GET['id'];
}
/*
function object_to_array($object) {
 if (is_object($object)) {
  return array_map(__FUNCTION__, get_object_vars($object));
 } else if (is_array($object)) {
  return array_map(__FUNCTION__, $object);
 } else {
  return $object;
 }
}

$fp = fopen('lidn.txt', 'w');
		fwrite($fp, json_encode($employes));
		fclose($fp);
*/