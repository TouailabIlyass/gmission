<?php

define("__DB",     "g_mission_emp");
define("__TABLE",     "transport");

if($_SERVER['REQUEST_METHOD'] === 'GET')
{
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");


include_once 'Dao.php';
//include_once 'models/Employe.php';
	
	$dao = new Dao(__DB);
	if(isset($_GET['cin']))
	{
		$data=$dao->getList(__TABLE,true,false,"where emp_cin = '".$_GET['cin']."'");
		if($data[0]->type==1)
		{
			$data["Avion"]=array();
			$trans=$dao->getList('avion',true,false,"where id = '".$data[0]->id_t."'");
			$data["Avion"]=$trans;
		}
		else if($data[0]->type==2)
		{
			$data["Avion"]=array();
			$trans=$dao->getList('train',true,false,"where id = '".$data->id_t."'");
			$data["Train"]=$trans;
		}
		else if($data[0]->type==3)
		{
			$data["Avion"]=array();
			$trans=$dao->getList('ctm',true,false,"where id = '".$data->id_t."'");
			$data["Ctm"]=$trans;
		}
		else if($data[0]->type==4)
		{
			$data["Avion"]=array();
			$trans=$dao->getList('vehicule',true,false,"where id = '".$data->id_t."'");
			$data["Vehicule"]=$trans;
		}
	    http_response_code(200);
	    echo json_encode($data);
	}
	else
	{
		$data=$dao->getList(__TABLE,true);
	    http_response_code(200);
	    echo json_encode($data);
	}
 	
    $dao->close();
/////
}else if($_SERVER['REQUEST_METHOD'] === 'POST')
{/////////////

}
else if($_SERVER['REQUEST_METHOD'] === 'PUT')
{
echo "put".$_GET['id'];
}
else if($_SERVER['REQUEST_METHOD'] === 'DELETE')
{

	echo "delete".$_GET['id'];
}