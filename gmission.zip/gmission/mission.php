<?php

define("__DB",     "g_mission_emp");
define("__TABLE",     "mission");

if($_SERVER['REQUEST_METHOD'] === 'GET')
{
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once 'Dao.php';
//include_once 'models/Employe.php';
	
	$dao = new Dao(__DB);
	if(isset($_GET['cin']))
	{
		$data=$dao->getList(__TABLE,true,"where cin = '".$_GET['cin']."'");
	    http_response_code(200);
	    echo json_encode($data);
	}
	else
	{
		$data=$dao->getList(__TABLE,true);
	    http_response_code(200);
	    echo json_encode($data);
	}
 	
    $dao->close();
/////
}else if($_SERVER['REQUEST_METHOD'] === 'POST')
{/////////////

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 

include_once 'Dao.php';
 

$dao = new Dao(__DB);

$data = json_decode(file_get_contents("php://input"));
$data->id=0;
$dao->insert(__TABLE,(array)$data);
echo json_encode($data);
$dao->close();
}
else if($_SERVER['REQUEST_METHOD'] === 'PUT')
{
echo "put".$_GET['id'];
}
else if($_SERVER['REQUEST_METHOD'] === 'DELETE')
{

	echo "delete".$_GET['id'];
}
