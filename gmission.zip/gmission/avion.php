<?php

define("__DB",     "g_mission_emp");
define("__TABLE",     "avion");

if($_SERVER['REQUEST_METHOD'] === 'GET')
{
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once 'Dao.php';
//include_once 'models/Employe.php';
	
	$dao = new Dao(__DB);
	if(isset($_GET['id']))
	{
		$data=$dao->getList(__TABLE,true,"where id = '".$_GET['id']."'");
	    http_response_code(200);
	    echo json_encode($data);
	}
	else
	{
		$data=$dao->getList(__TABLE,true);
	    http_response_code(200);
	    echo json_encode($data);
	}
 	
    $dao->close();
/////
}else if($_SERVER['REQUEST_METHOD'] === 'POST')
{/////////////

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'Dao.php';
 

$dao = new Dao(__DB);

$data = json_decode(file_get_contents("php://input"));
$fp = fopen('lidn.txt', 'w');
		fwrite($fp, json_encode($data));
		fclose($fp);
echo json_encode($data);
$data->id=0;
$id=$dao->insert(__TABLE,(array)$data);
$list=explode(",", $data->accompagne);
$accompagne=array("id"=>"0", "idtransport"=>$id, "cin"=>"0");
	for ($i=0; $i <count($list)-1 ; $i++) { 
		$accompagne['cin'] = $list[$i];
		$dao->insert("accompagne",$accompagne);
	}
	if(isset($_GET['cin']))
	{
		$transport = array('id' => 0,'id_t'=>$id,'type'=>'1','emp_cin'=>$_GET['cin']);
		$dao->insert("transport",$transport);
	}
	$dao->close();
}
else if($_SERVER['REQUEST_METHOD'] === 'PUT')
{
echo "put".$_GET['id'];
}
else if($_SERVER['REQUEST_METHOD'] === 'DELETE')
{

	echo "delete".$_GET['id'];
}