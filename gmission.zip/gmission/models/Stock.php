<?php 


class Stock { 
   
     public $type;
public $somme;


   public function __construct()
   {
      $a=func_get_args();

      if (func_num_args()==0)
      $this->construct1();
  
      else
      $this->construct2($a);
      
   }

   public function construct1()
   {
      $this->type='';
$this->somme='';

   }

   public function construct2($a)
   {
     $this->type=$a[0];
$this->somme=$a[1];

   }

   public function getType(){ return $this->type;}
public function getSomme(){ return $this->somme;}


   public function setType($var){ $this->type=$var;}
public function setSomme($var){ $this->somme=$var;}

    public  function getPrimaryKey()
    {
    $tab['type']=$this->type;
return serialize($tab);
    }

   public static function getAttr()
   {  
        $attr=array();

        $attr[]="getType";
$attr[]="getSomme";

        return $attr;
   }

}
  