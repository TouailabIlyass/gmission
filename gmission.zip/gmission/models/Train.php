<?php 


class Train { 
   
     public $id;
public $numBon;
public $prix;
public $destination;


   public function __construct()
   {
      $a=func_get_args();

      if (func_num_args()==0)
      $this->construct1();
  
      else
      $this->construct2($a);
      
   }

   public function construct1()
   {
      $this->id='';
$this->numbon='';
$this->prix='';
$this->destination='';

   }

   public function construct2($a)
   {
     $this->id=$a[0];
$this->numbon=$a[1];
$this->prix=$a[2];
$this->destination=$a[3];

   }

   public function getId(){ return $this->id;}
public function getNumbon(){ return $this->numbon;}
public function getPrix(){ return $this->prix;}
public function getDestination(){ return $this->destination;}


   public function setId($var){ $this->id=$var;}
public function setNumbon($var){ $this->numbon=$var;}
public function setPrix($var){ $this->prix=$var;}
public function setDestination($var){ $this->destination=$var;}

    public  function getPrimaryKey()
    {
    $tab['id']=$this->id;
return serialize($tab);
    }

   public static function getAttr()
   {  
        $attr=array();

        $attr[]="getId";
$attr[]="getNumbon";
$attr[]="getPrix";
$attr[]="getDestination";

        return $attr;
   }

}
  