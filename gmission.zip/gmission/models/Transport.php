<?php 


class Transport { 
   
     public $id;
public $id_t;
public $type;
public $emp_cin;


   public function __construct()
   {
      $a=func_get_args();

      if (func_num_args()==0)
      $this->construct1();
  
      else
      $this->construct2($a);
      
   }

   public function construct1()
   {
      $this->id='';
$this->id_t='';
$this->type='';
$this->emp_cin='';

   }

   public function construct2($a)
   {
     $this->id=$a[0];
$this->id_t=$a[1];
$this->type=$a[2];
$this->emp_cin=$a[3];

   }

   public function getId(){ return $this->id;}
public function getId_t(){ return $this->id_t;}
public function getType(){ return $this->type;}
public function getEmp_cin(){ return $this->emp_cin;}


   public function setId($var){ $this->id=$var;}
public function setId_t($var){ $this->id_t=$var;}
public function setType($var){ $this->type=$var;}
public function setEmp_cin($var){ $this->emp_cin=$var;}

    public  function getPrimaryKey()
    {
    $tab['id']=$this->id;
return serialize($tab);
    }

   public static function getAttr()
   {  
        $attr=array();

        $attr[]="getId";
$attr[]="getId_t";
$attr[]="getType";
$attr[]="getEmp_cin";

        return $attr;
   }

}
  