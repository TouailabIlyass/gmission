<?php 


class Vehicule { 
   
     public $id;
public $marque;
public $destination;
public $distance;
public $conducteur_cin;


   public function __construct()
   {
      $a=func_get_args();

      if (func_num_args()==0)
      $this->construct1();
  
      else
      $this->construct2($a);
      
   }

   public function construct1()
   {
      $this->id='';
$this->marque='';
$this->destination='';
$this->distance='';
$this->conducteur='';

   }

   public function construct2($a)
   {
     $this->id=$a[0];
$this->marque=$a[1];
$this->destination=$a[2];
$this->distance=$a[3];
$this->conducteur=$a[4];

   }

   public function getId(){ return $this->id;}
public function getMarque(){ return $this->marque;}
public function getDestination(){ return $this->destination;}
public function getDistance(){ return $this->distance;}
public function getConducteur(){ return $this->conducteur;}


   public function setId($var){ $this->id=$var;}
public function setMarque($var){ $this->marque=$var;}
public function setDestination($var){ $this->destination=$var;}
public function setDistance($var){ $this->distance=$var;}
public function setConducteur($var){ $this->conducteur=$var;}

    public  function getPrimaryKey()
    {
    $tab['id']=$this->id;
return serialize($tab);
    }

   public static function getAttr()
   {  
        $attr=array();

        $attr[]="getId";
$attr[]="getMarque";
$attr[]="getDestination";
$attr[]="getDistance";
$attr[]="getConducteur";

        return $attr;
   }

}
  