<?php 


class Mission { 
   
     public $id;
public $type;
public $date;
public $cin_emp;


   public function __construct()
   {
      $a=func_get_args();

      if (func_num_args()==0)
      $this->construct1();
  
      else
      $this->construct2($a);
      
   }

   public function construct1()
   {
      $this->id='';
$this->type='';
$this->date='';
$this->cin_emp='';

   }

   public function construct2($a)
   {
     $this->id=$a[0];
$this->type=$a[1];
$this->date=$a[2];
$this->cin_emp=$a[3];

   }

   public function getId(){ return $this->id;}
public function getType(){ return $this->type;}
public function getDate(){ return $this->date;}
public function getCin_emp(){ return $this->cin_emp;}


   public function setId($var){ $this->id=$var;}
public function setType($var){ $this->type=$var;}
public function setDate($var){ $this->date=$var;}
public function setCin_emp($var){ $this->cin_emp=$var;}

    public  function getPrimaryKey()
    {
    $tab['id']=$this->id;
return serialize($tab);
    }

   public static function getAttr()
   {  
        $attr=array();

        $attr[]="getId";
$attr[]="getType";
$attr[]="getDate";
$attr[]="getCin_emp";

        return $attr;
   }

}
  