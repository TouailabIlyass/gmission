<?php 


class Employe { 
   
     public $cin;
public $nom;
public $prenom;
public $grade;
public $fonction;
public $type;


   public function __construct()
   {
      $a=func_get_args();

      if (func_num_args()==0)
      $this->construct1();
  
      else
      $this->construct2($a);
      
   }

   public function construct1()
   {
      $this->cin='';
$this->nom='';
$this->prenom='';
$this->grade='';
$this->fonction='';
$this->type='';

   }

   public function construct2($a)
   {
     $this->cin=$a[0];
$this->nom=$a[1];
$this->prenom=$a[2];
$this->grade=$a[3];
$this->fonction=$a[4];
$this->type=$a[5];

   }

   public function getCin(){ return $this->cin;}
public function getNom(){ return $this->nom;}
public function getPrenom(){ return $this->prenom;}
public function getGrade(){ return $this->grade;}
public function getFonction(){ return $this->fonction;}
public function getType(){ return $this->type;}


   public function setCin($var){ $this->cin=$var;}
public function setNom($var){ $this->nom=$var;}
public function setPrenom($var){ $this->prenom=$var;}
public function setGrade($var){ $this->grade=$var;}
public function setFonction($var){ $this->fonction=$var;}
public function setType($var){ $this->type=$var;}

    public  function getPrimaryKey()
    {
    $tab['cin']=$this->cin;
return serialize($tab);
    }

   public static function getAttr()
   {  
        $attr=array();

        $attr[]="getCin";
$attr[]="getNom";
$attr[]="getPrenom";
$attr[]="getGrade";
$attr[]="getFonction";
$attr[]="getType";

        return $attr;
   }

}
  