<?php 


class Accompagne { 
   
     public $id;
public $idtransport;
public $cin;


   public function __construct()
   {
      $a=func_get_args();

      if (func_num_args()==0)
      $this->construct1();
  
      else
      $this->construct2($a);
      
   }

   public function construct1()
   {
      $this->id='';
$this->idtransport='';
$this->cin='';

   }

   public function construct2($a)
   {
     $this->id=$a[0];
$this->idtransport=$a[1];
$this->cin=$a[2];

   }

   public function getId(){ return $this->id;}
public function getIdtransport(){ return $this->idtransport;}
public function getCin(){ return $this->cin;}


   public function setId($var){ $this->id=$var;}
public function setIdtransport($var){ $this->idtransport=$var;}
public function setCin($var){ $this->cin=$var;}

    public  function getPrimaryKey()
    {
    $tab['id']=$this->id;
return serialize($tab);
    }

   public static function getAttr()
   {  
        $attr=array();

        $attr[]="getId";
$attr[]="getIdtransport";
$attr[]="getCin";

        return $attr;
   }

}
  