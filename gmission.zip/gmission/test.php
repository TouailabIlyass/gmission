<?php

require_once 'Dao.php';

$dao = new Dao('g_mission_emp');
$dao->getList('stock',false,"",true);